package com.example.nbyula;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Registration extends AppCompatActivity {


    EditText name,age, gender,contact,email,password;
    Button submit;
    DatabaseReference studentdbref;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        name =findViewById(R.id.name);
        age =findViewById(R.id.age);
        gender =findViewById(R.id.gender);
        contact =findViewById(R.id.contact);
        email =findViewById(R.id.email);
        password=findViewById(R.id.password);

        submit=findViewById(R.id.submit);

        auth = FirebaseAuth.getInstance();

        studentdbref = FirebaseDatabase.getInstance().getReference().child("details");

//        submit.setOnClickListener(v -> {
//            insertData();
//            opention();
//
//        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                insertData();
                opention();
            }
        });
    }

    public void opention()
    {
        Intent intent=new Intent(getApplicationContext(), Inquiry_form.class);
        startActivity(intent);
    }

    public void insertData()
    {
        String dname=name.getText().toString();
        String dage=age.getText().toString();
        String dgender=gender.getText().toString();
        String dcontact=contact.getText().toString();
        String demail=email.getText().toString();
        String dpass=password.getText().toString();

        auth.createUserWithEmailAndPassword(demail,dcontact).addOnCompleteListener(task -> {
            if(task.isSuccessful())
            {
                Toast.makeText(Registration.this,"Data inserted ",Toast.LENGTH_LONG).show();

            }
            else
            {

                Toast.makeText(Registration.this,"Data not inserted ",Toast.LENGTH_LONG).show();
            }

        });

        details deta=new details(dname,dage,dgender,dcontact,demail,dpass);
        deta.setDname(dname);
        deta.setDage(dage);
        deta.setDgender(dgender);
        deta.setDcontact(dcontact);
        deta.setDemail(demail);
        deta.setDpass(dpass);

        studentdbref.push().setValue(deta);
        Toast.makeText(Registration.this,"Data fghfg inserted ",Toast.LENGTH_LONG).show();



    }
}