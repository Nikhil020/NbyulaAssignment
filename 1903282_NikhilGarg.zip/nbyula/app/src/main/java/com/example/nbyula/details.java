package com.example.nbyula;

public class details {
    String dname;
    String dage;
    String dgender;
    String dcontact;
    String demail;
    String dpass;
    String dtitle;
    String dtime;
    String dagenda;
    String dguest_name;

    public String getDtitle() {
        return dtitle;
    }

    public void setDtitle(String dtitle) {
        this.dtitle = dtitle;
    }

    public String getDtime() {
        return dtime;
    }

    public void setDtime(String dtime) {
        this.dtime = dtime;
    }

    public String getDagenda() {
        return dagenda;
    }

    public void setDagenda(String dagenda) {
        this.dagenda = dagenda;
    }

    public String getDguest_name() {
        return dguest_name;
    }

    public void setDguest_name(String dguest_name) {
        this.dguest_name = dguest_name;
    }

    public void setDname(String dname) {
        this.dname = dname;
    }

    public void setDage(String dage) {
        this.dage = dage;
    }

    public void setDgender(String dgender) {
        this.dgender = dgender;
    }

    public void setDcontact(String dcontact) {
        this.dcontact = dcontact;
    }

    public void setDemail(String demail) {
        this.demail = demail;
    }

    public void setDpass(String dpass) {
        this.dpass = dpass;
    }

    public String getDname() {
        return dname;
    }

    public String getDage() {
        return dage;
    }

    public String getDgender() {
        return dgender;
    }

    public String getDcontact() {
        return dcontact;
    }

    public String getDemail() {
        return demail;
    }

    public String getDpass() {
        return dpass;
    }

    details(String dname, String dage, String dgender, String dcontact, String demail, String dpass) {
        this.dname = dname;
        this.dage = dage;
        this.dgender = dgender;
        this.dcontact = dcontact;
        this.demail = demail;
        this.dpass = dpass;
    }

    details(String dtitle,String dagenda,String dtime, String dguest_name)
    {
        this.dtitle = dtitle;
        this.dagenda = dagenda;
        this.dtime = dtime;
        this.dguest_name = dguest_name;
    }

}
