package com.example.nbyula;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {
    EditText text,text2;
    private Button button,button2;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        text=findViewById(R.id.text);
        text2=findViewById(R.id.text2);

        button2=(Button) findViewById(R.id.login);
        button2.setOnClickListener(view -> openNext());

        button = (Button) findViewById(R.id.register);
        button.setOnClickListener(v -> openRegistration());
    }

    public void openNext()
    {
        Intent intent=new Intent(this, Inquiry_form.class);
        startActivity(intent);
    }

    public void openRegistration()
    {
        Intent abc=new Intent(this, Registration.class);
        startActivity(abc);
    }
}