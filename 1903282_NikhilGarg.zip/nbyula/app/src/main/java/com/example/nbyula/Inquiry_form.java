package com.example.nbyula;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Inquiry_form extends AppCompatActivity {

    EditText title,agenda, time,guest_name;
    Button submit;
    DatabaseReference studentdbref;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        title =findViewById(R.id.title);
        agenda =findViewById(R.id.agenda);
        time =findViewById(R.id.time);
        guest_name =findViewById(R.id.guest_name);

        submit=findViewById(R.id.submit);

        auth = FirebaseAuth.getInstance();

        studentdbref = FirebaseDatabase.getInstance().getReference().child("details");

        submit.setOnClickListener(v -> {
            insertData();
            openn();

        });

    }

    public void openn()
    {
        Intent intent=new Intent(this, done.class);
        startActivity(intent);
    }
/*
    private void switchActivities() {
        Intent switchActivityIntent = new Intent(this, Home.class);
        startActivity(switchActivityIntent);
    }
*/
    public void insertData()
    {
        String dtitle=title.getText().toString();
        String dagenda=agenda.getText().toString();
        String dtime=time.getText().toString();
        String dguest_name=guest_name.getText().toString();

     /*   auth.createUserWithEmailAndPassword().addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful())
                {
                    Toast.makeText(Inquiry_form.this,"Data inserted ",Toast.LENGTH_LONG).show();

                }
                else
                {

                    Toast.makeText(Inquiry_form.this,"Data not inserted ",Toast.LENGTH_LONG).show();
                }

            }
        });
*/
        details deta=new details(dtitle,dagenda,dtime,dguest_name);
        deta.setDtitle(dtitle);
        deta.setDagenda(dagenda);
        deta.setDtime(dtime);
        deta.setDguest_name(dguest_name);


        studentdbref.push().setValue(deta);
        Toast.makeText(Inquiry_form.this,"Data fghfg inserted ",Toast.LENGTH_LONG).show();



    }
}